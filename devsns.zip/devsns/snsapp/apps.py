from django.apps import AppConfig


class SnsappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'snsapp'
